import random
import copy

BLANK = 0
AMM = 1

# 弾丸一覧
BULLETS_LIST = [
    [BLANK,AMM],
    [BLANK,BLANK,AMM],
    [BLANK,BLANK,BLANK,AMM],
    [BLANK,BLANK,AMM,AMM],
    [BLANK,BLANK,BLANK,AMM,AMM],
    [BLANK,BLANK,AMM,AMM,AMM],
    [BLANK,BLANK,BLANK,BLANK,AMM,AMM],
    [BLANK,BLANK,BLANK,AMM,AMM,AMM],
    [BLANK,BLANK,AMM,AMM,AMM,AMM]
]

class Gun:
    def __init__(self)->None:
        self.bullets = copy.deepcopy(BULLETS_LIST[random.randint(0, len(BULLETS_LIST)-1)])
        self.initBull = copy.deepcopy(self.bullets)
        random.shuffle(self.bullets)
        self.damMul = False

    def setDamMul(self) -> None:
        self.damMul=True

    def unsetDamMul(self) -> None:
        self.damMul=False

    def bang(self) -> int:
        bull = self.bullets.pop(0)
        if bull==BLANK:
            return BLANK
        else:
            return AMM

    def getNext(self) -> int:
        return self.bullets[0]

    def getNumOfBul(self) -> int:
        return len(self.bullets)